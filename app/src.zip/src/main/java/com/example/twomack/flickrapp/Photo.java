package com.example.twomack.flickrapp;

public class Photo {

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }




}
